"""Construction authority, attestation, and chained receipt adapter.

This adapter reuses Aura's relational-authority contracts. It evaluates digital
readiness and preserves human release requirements; it never authorizes physical
work or creates cryptographic identity claims.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math
import re
from typing import Any, Iterable, Mapping

from aura_event_contracts import stable_digest, stable_id
from aura_relational_authority import (
    ApprovalAttestation,
    AuthorityGrant,
    ChainedAuthorityReceipt,
    GENESIS_CHAIN_DIGEST,
    GovernanceDecision,
    QuorumPolicy,
    RiskClass,
    TrustedCheckpoint,
    evaluate_governance,
    verify_receipt_chain,
)
from aura_construction_contracts import (
    ConstructionScope,
    PATCH_AUTHORITY,
    PROPOSAL_ONLY,
    VSA_PATCH_AUTHORITY,
)
from aura_construction_state import (
    ConstructionProjectState,
    ConstructionReadinessReport,
    query_claim_readiness,
)

CONSTRUCTION_AUTHORITY_VERSION = "AURA_CONSTRUCTION_AUTHORITY_V1"
_HEX = re.compile(r"^[0-9a-f]+$")


def _text(value: Any, name: str) -> str:
    if type(value) is not str or not value.strip():
        raise ValueError(f"{name} must be a non-empty string")
    normalized = " ".join(value.split())
    if normalized != value:
        raise ValueError(f"{name} must be normalized")
    return value


def _digest(value: Any, name: str) -> str:
    if type(value) is not str:
        raise ValueError(f"{name} must be a hexadecimal digest")
    normalized = value.lower()
    if len(normalized) not in {32, 64} or _HEX.fullmatch(normalized) is None:
        raise ValueError(f"{name} must be a 32- or 64-character hexadecimal digest")
    return normalized


def _tuple_strings(value: Any, name: str, *, allow_empty: bool = True) -> tuple[str, ...]:
    if type(value) is not tuple:
        raise ValueError(f"{name} must be a tuple")
    if any(type(item) is not str or not item for item in value):
        raise ValueError(f"{name} contains an invalid value")
    if len(value) != len(set(value)):
        raise ValueError(f"{name} must not contain duplicates")
    if not allow_empty and not value:
        raise ValueError(f"{name} must not be empty")
    return value


def _normalized_unique(values: Iterable[Any], name: str, *, allow_empty: bool = True) -> tuple[str, ...]:
    result: list[str] = []
    seen: set[str] = set()
    for raw in values:
        if type(raw) is not str:
            raise ValueError(f"{name} contains a non-string value")
        normalized = " ".join(raw.split())
        if not normalized:
            raise ValueError(f"{name} contains an empty value")
        if normalized in seen:
            raise ValueError(f"{name} contains duplicate or normalization-colliding values")
        seen.add(normalized)
        result.append(normalized)
    if not allow_empty and not result:
        raise ValueError(f"{name} must not be empty")
    return tuple(sorted(result))


def _trusted_refs(values: Iterable[Any], name: str) -> tuple[str, ...]:
    return _normalized_unique(values, name, allow_empty=False)


def _verified_digest_bindings(
    values: Mapping[str, str],
    name: str,
) -> dict[str, str]:
    if not isinstance(values, Mapping) or not values:
        raise ValueError(f"{name} must be a non-empty mapping")
    result: dict[str, str] = {}
    for raw_ref, raw_digest in values.items():
        ref = _text(raw_ref, f"{name}.reference")
        if ref in result:
            raise ValueError(f"{name} contains a duplicate reference")
        result[ref] = _digest(raw_digest, f"{name}[{ref}]")
    return result


def _timestamp(value: Any, name: str) -> float:
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite")
    return number


def _validate_authority_boundary(
    *,
    proposal_only: bool,
    human_release_required: bool,
    physical_work_authorized: bool,
    patch_authority: str,
    vsa_patch_authority: bool,
) -> None:
    if proposal_only is not True or human_release_required is not True or physical_work_authorized is not False:
        raise ValueError("construction authority boundary was modified")
    if patch_authority != PATCH_AUTHORITY or vsa_patch_authority is not False:
        raise ValueError("construction patch-authority boundary was modified")


@dataclass(frozen=True)
class ConstructionActionRequest:
    action_id: str
    action_digest: str
    scope: ConstructionScope
    action_kind: str
    policy_scope: str
    capability_scope: str
    risk_class: str
    required_claim_ids: tuple[str, ...]
    created_at: float
    expires_at: float
    version: str = CONSTRUCTION_AUTHORITY_VERSION
    proposal_only: bool = PROPOSAL_ONLY
    human_release_required: bool = True
    physical_work_authorized: bool = False
    patch_authority: str = PATCH_AUTHORITY
    vsa_patch_authority: bool = VSA_PATCH_AUTHORITY

    def __post_init__(self) -> None:
        if self.version != CONSTRUCTION_AUTHORITY_VERSION:
            raise ValueError("unsupported construction authority version")
        if type(self.scope) is not ConstructionScope:
            raise ValueError("action scope must be an exact ConstructionScope")
        _text(self.action_kind, "action.action_kind")
        _text(self.policy_scope, "action.policy_scope")
        _text(self.capability_scope, "action.capability_scope")
        project_policy = f"construction/{self.scope.project_id}"
        if not (
            self.policy_scope == project_policy
            or self.policy_scope.startswith(f"{project_policy}/")
        ):
            raise ValueError("action policy scope is outside its construction project")
        if (
            not self.capability_scope.startswith("construction.")
            or self.capability_scope == "construction."
        ):
            raise ValueError("action capability scope must be construction-scoped")
        if self.risk_class not in {item.value for item in RiskClass}:
            raise ValueError(f"unknown action risk_class: {self.risk_class}")
        _tuple_strings(self.required_claim_ids, "action.required_claim_ids", allow_empty=False)
        created = _timestamp(self.created_at, "action.created_at")
        if _timestamp(self.expires_at, "action.expires_at") <= created:
            raise ValueError("action expires_at must be later than created_at")
        _validate_authority_boundary(
            proposal_only=self.proposal_only,
            human_release_required=self.human_release_required,
            physical_work_authorized=self.physical_work_authorized,
            patch_authority=self.patch_authority,
            vsa_patch_authority=self.vsa_patch_authority,
        )
        payload = self._identity_payload()
        if self.action_digest != stable_digest(payload):
            raise ValueError("action digest does not match its content")
        if self.action_id != stable_id("construction-action", payload):
            raise ValueError("action ID does not match its content")

    @classmethod
    def create(
        cls,
        *,
        scope: ConstructionScope,
        action_kind: str,
        policy_scope: str,
        capability_scope: str,
        risk_class: str | RiskClass,
        required_claim_ids: Iterable[str],
        created_at: float,
        expires_at: float,
    ) -> "ConstructionActionRequest":
        if type(scope) is not ConstructionScope:
            raise ValueError("scope must be an exact ConstructionScope")
        risk = risk_class.value if isinstance(risk_class, RiskClass) else str(risk_class).upper()
        values = {
            "scope": scope,
            "action_kind": " ".join(str(action_kind).split()),
            "policy_scope": " ".join(str(policy_scope).split()),
            "capability_scope": " ".join(str(capability_scope).split()),
            "risk_class": risk,
            "required_claim_ids": _normalized_unique(required_claim_ids, "required_claim_ids", allow_empty=False),
            "created_at": _timestamp(created_at, "created_at"),
            "expires_at": _timestamp(expires_at, "expires_at"),
            "version": CONSTRUCTION_AUTHORITY_VERSION,
            "proposal_only": PROPOSAL_ONLY,
            "human_release_required": True,
            "physical_work_authorized": False,
            "patch_authority": PATCH_AUTHORITY,
            "vsa_patch_authority": VSA_PATCH_AUTHORITY,
        }
        payload = cls._payload_from_values(values)
        return cls(action_id=stable_id("construction-action", payload), action_digest=stable_digest(payload), **values)

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ConstructionActionRequest":
        data = dict(value)
        return cls(
            action_id=str(data.get("action_id", "")),
            action_digest=str(data.get("action_digest", "")),
            scope=ConstructionScope.from_dict(dict(data.get("scope") or {})),
            action_kind=str(data.get("action_kind", "")),
            policy_scope=str(data.get("policy_scope", "")),
            capability_scope=str(data.get("capability_scope", "")),
            risk_class=str(data.get("risk_class", "")),
            required_claim_ids=tuple(data.get("required_claim_ids", ())),
            created_at=float(data.get("created_at")),
            expires_at=float(data.get("expires_at")),
            version=str(data.get("version", "")),
            proposal_only=data.get("proposal_only"),
            human_release_required=data.get("human_release_required"),
            physical_work_authorized=data.get("physical_work_authorized"),
            patch_authority=str(data.get("patch_authority", "")),
            vsa_patch_authority=data.get("vsa_patch_authority"),
        )

    @staticmethod
    def _payload_from_values(values: Mapping[str, Any]) -> dict[str, Any]:
        return {**values, "scope": values["scope"].to_dict(), "required_claim_ids": list(values["required_claim_ids"])}

    def _identity_payload(self) -> dict[str, Any]:
        data = asdict(self)
        data.pop("action_id")
        data.pop("action_digest")
        return data

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ConstructionAuthorityResult:
    result_id: str
    result_digest: str
    project_id: str
    scope_key: str
    request_id: str
    request_digest: str
    required_claim_ids: tuple[str, ...]
    state_digest: str
    governance_decision_id: str
    governance_decision_digest: str
    governance_authorized: bool
    evidence_ready: bool
    digitally_ready: bool
    readiness_reports: tuple[ConstructionReadinessReport, ...]
    missing_reasons: tuple[str, ...]
    evaluated_at: float
    expires_at: float
    version: str = CONSTRUCTION_AUTHORITY_VERSION
    proposal_only: bool = PROPOSAL_ONLY
    human_release_required: bool = True
    physical_work_authorized: bool = False
    patch_authority: str = PATCH_AUTHORITY
    vsa_patch_authority: bool = VSA_PATCH_AUTHORITY

    def __post_init__(self) -> None:
        if self.version != CONSTRUCTION_AUTHORITY_VERSION:
            raise ValueError("unsupported construction authority result version")
        _text(self.project_id, "result.project_id")
        _text(self.scope_key, "result.scope_key")
        if not self.scope_key.startswith(f"{self.project_id}/"):
            raise ValueError("authority result scope does not belong to its project")
        _text(self.request_id, "result.request_id")
        _digest(self.request_digest, "result.request_digest")
        _tuple_strings(
            self.required_claim_ids,
            "result.required_claim_ids",
            allow_empty=False,
        )
        _digest(self.state_digest, "result.state_digest")
        _text(self.governance_decision_id, "result.governance_decision_id")
        _digest(self.governance_decision_digest, "result.governance_decision_digest")
        flags = (
            self.governance_authorized,
            self.evidence_ready,
            self.digitally_ready,
        )
        if any(type(value) is not bool for value in flags):
            raise ValueError("authority result flags must be booleans")
        reports_are_exact = (
            type(self.readiness_reports) is tuple
            and bool(self.readiness_reports)
            and all(
                type(item) is ConstructionReadinessReport
                for item in self.readiness_reports
            )
        )
        if not reports_are_exact:
            raise ValueError("authority result requires exact readiness reports")
        report_claims = tuple(sorted(item.claim_id for item in self.readiness_reports))
        if report_claims != self.required_claim_ids:
            raise ValueError("authority result readiness reports do not match required claims")
        if any(item.state_digest != self.state_digest for item in self.readiness_reports):
            raise ValueError("authority result mixes readiness reports from another state")
        actual_evidence_ready = all(item.ready for item in self.readiness_reports)
        if self.evidence_ready is not actual_evidence_ready:
            raise ValueError("authority result evidence-ready flag is inconsistent")
        _tuple_strings(self.missing_reasons, "result.missing_reasons")
        evaluated = _timestamp(self.evaluated_at, "result.evaluated_at")
        if _timestamp(self.expires_at, "result.expires_at") <= evaluated:
            raise ValueError("authority result expires_at must be later than evaluated_at")
        expected_ready = self.governance_authorized and self.evidence_ready and not self.missing_reasons
        if self.digitally_ready is not expected_ready:
            raise ValueError("authority result digital-readiness flag is inconsistent")
        _validate_authority_boundary(
            proposal_only=self.proposal_only,
            human_release_required=self.human_release_required,
            physical_work_authorized=self.physical_work_authorized,
            patch_authority=self.patch_authority,
            vsa_patch_authority=self.vsa_patch_authority,
        )
        payload = self._identity_payload()
        if self.result_digest != stable_digest(payload):
            raise ValueError("authority result digest does not match its content")
        if self.result_id != stable_id("construction-authority-result", payload):
            raise ValueError("authority result ID does not match its content")

    @classmethod
    def create(
        cls,
        *,
        request: ConstructionActionRequest,
        state: ConstructionProjectState,
        governance_decision: GovernanceDecision,
        readiness_reports: tuple[ConstructionReadinessReport, ...],
        evaluated_at: float,
    ) -> "ConstructionAuthorityResult":
        request.__post_init__()
        state.__post_init__()
        current = _timestamp(evaluated_at, "evaluated_at")
        if request.scope.project_id != state.project_id:
            raise ValueError("authority result request and state project do not match")
        _validate_decision_binding(governance_decision, request, now=current)
        evidence_ready = all(item.ready for item in readiness_reports)
        reasons: set[str] = set()
        for report in readiness_reports:
            reasons.update(f"claim:{report.claim_id}:{item}" for item in report.blockers)
        reasons.update(str(item) for item in governance_decision.authority_missing_reasons)
        if not governance_decision.authorized:
            reasons.add("governance_not_authorized")
        ready = governance_decision.authorized and evidence_ready and not reasons
        values = {
            "project_id": request.scope.project_id,
            "scope_key": request.scope.scope_key,
            "request_id": request.action_id,
            "request_digest": request.action_digest,
            "required_claim_ids": request.required_claim_ids,
            "state_digest": state.state_digest,
            "governance_decision_id": governance_decision.decision_id,
            "governance_decision_digest": governance_decision.decision_digest,
            "governance_authorized": bool(governance_decision.authorized),
            "evidence_ready": evidence_ready,
            "digitally_ready": ready,
            "readiness_reports": readiness_reports,
            "missing_reasons": tuple(sorted(reasons)),
            "evaluated_at": current,
            "expires_at": _timestamp(
                min(request.expires_at, governance_decision.expires_at)
                if governance_decision.authorized
                else request.expires_at,
                "expires_at",
            ),
            "version": CONSTRUCTION_AUTHORITY_VERSION,
            "proposal_only": PROPOSAL_ONLY,
            "human_release_required": True,
            "physical_work_authorized": False,
            "patch_authority": PATCH_AUTHORITY,
            "vsa_patch_authority": VSA_PATCH_AUTHORITY,
        }
        payload = cls._payload_from_values(values)
        return cls(
            result_id=stable_id("construction-authority-result", payload),
            result_digest=stable_digest(payload),
            **values,
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ConstructionAuthorityResult":
        data = dict(value)
        return cls(
            result_id=str(data.get("result_id", "")),
            result_digest=str(data.get("result_digest", "")),
            project_id=str(data.get("project_id", "")),
            scope_key=str(data.get("scope_key", "")),
            request_id=str(data.get("request_id", "")),
            request_digest=str(data.get("request_digest", "")),
            required_claim_ids=tuple(data.get("required_claim_ids", ())),
            state_digest=str(data.get("state_digest", "")),
            governance_decision_id=str(data.get("governance_decision_id", "")),
            governance_decision_digest=str(data.get("governance_decision_digest", "")),
            governance_authorized=data.get("governance_authorized"),
            evidence_ready=data.get("evidence_ready"),
            digitally_ready=data.get("digitally_ready"),
            readiness_reports=tuple(
                ConstructionReadinessReport.from_dict(dict(item))
                for item in data.get("readiness_reports", ())
            ),
            missing_reasons=tuple(data.get("missing_reasons", ())),
            evaluated_at=float(data.get("evaluated_at")),
            expires_at=float(data.get("expires_at")),
            version=str(data.get("version", "")),
            proposal_only=data.get("proposal_only"),
            human_release_required=data.get("human_release_required"),
            physical_work_authorized=data.get("physical_work_authorized"),
            patch_authority=str(data.get("patch_authority", "")),
            vsa_patch_authority=data.get("vsa_patch_authority"),
        )

    @staticmethod
    def _payload_from_values(values: Mapping[str, Any]) -> dict[str, Any]:
        return {
            **values,
            "required_claim_ids": list(values["required_claim_ids"]),
            "readiness_reports": [item.to_dict() for item in values["readiness_reports"]],
            "missing_reasons": list(values["missing_reasons"]),
        }

    def _identity_payload(self) -> dict[str, Any]:
        data = asdict(self)
        data.pop("result_id")
        data.pop("result_digest")
        return data

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _validate_decision_binding(
    decision: GovernanceDecision,
    request: ConstructionActionRequest,
    *,
    now: float,
) -> None:
    decision.validate_integrity()
    if decision.action_id != request.action_id:
        raise ValueError("governance decision is bound to another action ID")
    if decision.action_payload_digest != request.action_digest:
        raise ValueError("governance decision is bound to another action digest")
    if decision.policy_scope != request.policy_scope:
        raise ValueError("governance decision policy scope does not match")
    if decision.capability_scope != request.capability_scope:
        raise ValueError("governance decision capability scope does not match")
    if decision.authorized:
        if now >= decision.expires_at:
            raise ValueError("governance decision is expired")
        decision.validate_for_action(
            action_id=request.action_id,
            action_payload_digest=request.action_digest,
            policy_scope=request.policy_scope,
            capability_scope=request.capability_scope,
            now=now,
        )


def _validate_result_bindings(
    result: ConstructionAuthorityResult,
    *,
    request: ConstructionActionRequest,
    state: ConstructionProjectState,
    governance_decision: GovernanceDecision,
    now: float,
) -> None:
    result.__post_init__()
    request.__post_init__()
    state.__post_init__()
    _validate_decision_binding(governance_decision, request, now=now)
    expected = {
        "project_id": request.scope.project_id,
        "scope_key": request.scope.scope_key,
        "request_id": request.action_id,
        "request_digest": request.action_digest,
        "required_claim_ids": request.required_claim_ids,
        "state_digest": state.state_digest,
        "governance_decision_id": governance_decision.decision_id,
        "governance_decision_digest": governance_decision.decision_digest,
        "governance_authorized": governance_decision.authorized,
    }
    for field, value in expected.items():
        if getattr(result, field) != value:
            raise ValueError(f"authority result is not bound to the supplied {field}")
    if now < result.evaluated_at:
        raise ValueError("construction authority receipt cannot predate evaluation")
    if now >= result.expires_at:
        raise ValueError("construction authority result is expired")


def evaluate_construction_authority(
    *,
    request: ConstructionActionRequest,
    state: ConstructionProjectState,
    grants: Iterable[AuthorityGrant],
    attestations: Iterable[ApprovalAttestation],
    quorum_policy: QuorumPolicy,
    verified_authority_refs: Iterable[str],
    verified_attestation_refs: Iterable[str],
    proposer_principal_id: str = "",
    normal_policy: QuorumPolicy | None = None,
    emergency_reason: str = "",
    now: float,
) -> tuple[ConstructionAuthorityResult, GovernanceDecision]:
    """Evaluate exact Construction evidence and Aura relational authority.

    The evaluator is intentionally not injectable. This prevents a caller from
    supplying a self-consistent but unearned GovernanceDecision.
    """
    request.__post_init__()
    state.__post_init__()
    current = _timestamp(now, "now")
    if request.scope.project_id != state.project_id:
        raise ValueError("construction action request and project state do not match")
    if current >= request.expires_at:
        raise ValueError("construction action request is expired")
    quorum_policy.validate()
    if quorum_policy.risk_class != request.risk_class:
        raise ValueError("construction action risk class and quorum policy disagree")

    authority_refs = _trusted_refs(
        verified_authority_refs,
        "verified_authority_refs",
    )
    attestation_refs = _trusted_refs(
        verified_attestation_refs,
        "verified_attestation_refs",
    )
    reports = tuple(
        query_claim_readiness(state, claim_id=claim_id, now=current)
        for claim_id in request.required_claim_ids
    )
    decision = evaluate_governance(
        action_id=request.action_id,
        action_payload_digest=request.action_digest,
        policy_scope=request.policy_scope,
        capability_scope=request.capability_scope,
        grants=tuple(grants),
        attestations=tuple(attestations),
        quorum_policy=quorum_policy,
        verified_authority_refs=authority_refs,
        verified_attestation_refs=attestation_refs,
        proposer_principal_id=proposer_principal_id,
        normal_policy=normal_policy,
        emergency_reason=emergency_reason,
        now=current,
    )
    if type(decision) is not GovernanceDecision:
        raise ValueError("Aura governance evaluator returned an invalid decision type")
    _validate_decision_binding(decision, request, now=current)
    result = ConstructionAuthorityResult.create(
        request=request,
        state=state,
        governance_decision=decision,
        readiness_reports=reports,
        evaluated_at=current,
    )
    return result, decision


@dataclass(frozen=True)
class ConstructionReceiptBinding:
    binding_id: str
    binding_digest: str
    project_id: str
    request_id: str
    request_digest: str
    state_digest: str
    governance_decision_id: str
    governance_decision_digest: str
    authority_result_id: str
    authority_result_digest: str
    chain_receipt_id: str
    chain_digest: str
    externally_verified_receipt_ref: str
    created_at: float
    version: str = CONSTRUCTION_AUTHORITY_VERSION
    proposal_only: bool = PROPOSAL_ONLY
    human_release_required: bool = True
    physical_work_authorized: bool = False
    patch_authority: str = PATCH_AUTHORITY
    vsa_patch_authority: bool = VSA_PATCH_AUTHORITY

    def __post_init__(self) -> None:
        _text(self.project_id, "binding.project_id")
        _text(self.request_id, "binding.request_id")
        _digest(self.request_digest, "binding.request_digest")
        _digest(self.state_digest, "binding.state_digest")
        _text(self.governance_decision_id, "binding.governance_decision_id")
        _digest(self.governance_decision_digest, "binding.governance_decision_digest")
        _text(self.authority_result_id, "binding.authority_result_id")
        _digest(self.authority_result_digest, "binding.authority_result_digest")
        _text(self.chain_receipt_id, "binding.chain_receipt_id")
        _digest(self.chain_digest, "binding.chain_digest")
        _text(self.externally_verified_receipt_ref, "binding.externally_verified_receipt_ref")
        _timestamp(self.created_at, "binding.created_at")
        if self.version != CONSTRUCTION_AUTHORITY_VERSION:
            raise ValueError("unsupported construction receipt binding version")
        _validate_authority_boundary(
            proposal_only=self.proposal_only,
            human_release_required=self.human_release_required,
            physical_work_authorized=self.physical_work_authorized,
            patch_authority=self.patch_authority,
            vsa_patch_authority=self.vsa_patch_authority,
        )
        payload = self._identity_payload()
        if self.binding_digest != stable_digest(payload):
            raise ValueError("receipt binding digest does not match")
        if self.binding_id != stable_id("construction-receipt-binding", payload):
            raise ValueError("receipt binding ID does not match")

    @classmethod
    def create(
        cls,
        *,
        authority_result: ConstructionAuthorityResult,
        request: ConstructionActionRequest,
        state: ConstructionProjectState,
        governance_decision: GovernanceDecision,
        chain_receipt: ChainedAuthorityReceipt,
        externally_verified_receipt_ref: str,
        verified_receipt_bindings: Mapping[str, str],
        created_at: float,
    ) -> "ConstructionReceiptBinding":
        created = _timestamp(created_at, "created_at")
        _validate_result_bindings(
            authority_result,
            request=request,
            state=state,
            governance_decision=governance_decision,
            now=created,
        )
        chain_receipt.validate_integrity()
        if not authority_result.digitally_ready:
            raise ValueError("cannot issue a receipt for a non-ready authority result")
        external_ref = _text(
            externally_verified_receipt_ref,
            "externally_verified_receipt_ref",
        )
        bindings = _verified_digest_bindings(
            verified_receipt_bindings,
            "verified_receipt_bindings",
        )
        bound_digest = bindings.get(external_ref)
        if bound_digest != authority_result.result_digest:
            raise ValueError("external receipt reference is not bound to this authority result")
        receipt_is_bound = (
            chain_receipt.record_id == authority_result.result_id
            and chain_receipt.record_digest == authority_result.result_digest
        )
        if not receipt_is_bound:
            raise ValueError("chain receipt is not bound to the authority result")
        values = {
            "project_id": authority_result.project_id,
            "request_id": request.action_id,
            "request_digest": request.action_digest,
            "state_digest": state.state_digest,
            "governance_decision_id": governance_decision.decision_id,
            "governance_decision_digest": governance_decision.decision_digest,
            "authority_result_id": authority_result.result_id,
            "authority_result_digest": authority_result.result_digest,
            "chain_receipt_id": chain_receipt.receipt_id,
            "chain_digest": chain_receipt.chain_digest,
            "externally_verified_receipt_ref": external_ref,
            "created_at": created,
            "version": CONSTRUCTION_AUTHORITY_VERSION,
            "proposal_only": PROPOSAL_ONLY,
            "human_release_required": True,
            "physical_work_authorized": False,
            "patch_authority": PATCH_AUTHORITY,
            "vsa_patch_authority": VSA_PATCH_AUTHORITY,
        }
        payload = dict(values)
        return cls(
            binding_id=stable_id("construction-receipt-binding", payload),
            binding_digest=stable_digest(payload),
            **values,
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ConstructionReceiptBinding":
        data = dict(value)
        return cls(
            binding_id=str(data.get("binding_id", "")),
            binding_digest=str(data.get("binding_digest", "")),
            project_id=str(data.get("project_id", "")),
            request_id=str(data.get("request_id", "")),
            request_digest=str(data.get("request_digest", "")),
            state_digest=str(data.get("state_digest", "")),
            governance_decision_id=str(data.get("governance_decision_id", "")),
            governance_decision_digest=str(data.get("governance_decision_digest", "")),
            authority_result_id=str(data.get("authority_result_id", "")),
            authority_result_digest=str(data.get("authority_result_digest", "")),
            chain_receipt_id=str(data.get("chain_receipt_id", "")),
            chain_digest=str(data.get("chain_digest", "")),
            externally_verified_receipt_ref=str(data.get("externally_verified_receipt_ref", "")),
            created_at=float(data.get("created_at")),
            version=str(data.get("version", "")),
            proposal_only=data.get("proposal_only"),
            human_release_required=data.get("human_release_required"),
            physical_work_authorized=data.get("physical_work_authorized"),
            patch_authority=str(data.get("patch_authority", "")),
            vsa_patch_authority=data.get("vsa_patch_authority"),
        )

    def _identity_payload(self) -> dict[str, Any]:
        data = asdict(self)
        data.pop("binding_id")
        data.pop("binding_digest")
        return data

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def create_construction_receipt(
    *,
    authority_result: ConstructionAuthorityResult,
    request: ConstructionActionRequest,
    state: ConstructionProjectState,
    governance_decision: GovernanceDecision,
    ledger_id: str,
    sequence_number: int,
    previous_chain_digest: str = GENESIS_CHAIN_DIGEST,
    externally_verified_receipt_ref: str,
    verified_receipt_bindings: Mapping[str, str],
    created_at: float,
) -> tuple[ChainedAuthorityReceipt, ConstructionReceiptBinding]:
    created = _timestamp(created_at, "created_at")
    _validate_result_bindings(
        authority_result,
        request=request,
        state=state,
        governance_decision=governance_decision,
        now=created,
    )
    expected_ledger = f"construction-authority/{authority_result.project_id}"
    if ledger_id != expected_ledger:
        raise ValueError(f"construction authority receipt ledger must be {expected_ledger}")
    receipt = ChainedAuthorityReceipt.create(
        ledger_id=ledger_id,
        sequence_number=sequence_number,
        previous_chain_digest=previous_chain_digest,
        record_id=authority_result.result_id,
        record_digest=authority_result.result_digest,
        created_at=created,
    )
    binding = ConstructionReceiptBinding.create(
        authority_result=authority_result,
        request=request,
        state=state,
        governance_decision=governance_decision,
        chain_receipt=receipt,
        externally_verified_receipt_ref=externally_verified_receipt_ref,
        verified_receipt_bindings=verified_receipt_bindings,
        created_at=created,
    )
    return receipt, binding


def verify_construction_receipts(
    receipts: Iterable[ChainedAuthorityReceipt],
    *,
    results_by_id: Mapping[str, ConstructionAuthorityResult],
    trusted_checkpoint: TrustedCheckpoint | None = None,
    verified_checkpoint_refs: Iterable[str] = (),
):
    record_digests: dict[str, str] = {}
    for key, result in results_by_id.items():
        if type(result) is not ConstructionAuthorityResult:
            raise ValueError("results_by_id contains an invalid result type")
        result.__post_init__()
        if key != result.result_id:
            raise ValueError("results_by_id key does not match result identity")
        record_digests[key] = result.result_digest
    return verify_receipt_chain(
        receipts,
        record_digests=record_digests,
        trusted_checkpoint=trusted_checkpoint,
        verified_checkpoint_refs=verified_checkpoint_refs,
    )


__all__ = [
    "CONSTRUCTION_AUTHORITY_VERSION",
    "ConstructionActionRequest",
    "ConstructionAuthorityResult",
    "ConstructionReceiptBinding",
    "evaluate_construction_authority",
    "create_construction_receipt",
    "verify_construction_receipts",
]
